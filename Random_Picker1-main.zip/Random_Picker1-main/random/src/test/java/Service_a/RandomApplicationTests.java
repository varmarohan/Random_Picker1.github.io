package Service_a;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RandomApplicationTests {

	@Test
	void contextLoads() {
	}

}
